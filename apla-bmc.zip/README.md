# आपला BMC — Apla BMC

**Where the road-repair money for your road went.** A phone-first web app for any Mumbaikar: how much was spent on a road this monsoon, how often it was repaired, how often it broke again, which contractor did it, what it *should* have cost vs what was *billed*, whether the road is still under guarantee, and which red flags exist. It then gives three ways to push for action: **Me too**, **Share on WhatsApp**, **Ask BMC (ready-made RTI)**.

Not a complaint app — complaints still go to BMC's own MyBMC. Marathi by default, Hindi and English one tap away. No party, corporator or officer names, ever.

Team 23 · Claude Impact Lab Mumbai · 21 Nov 2026

| Road Card | My Ward |
|---|---|
| <img src="docs/road-card.png" width="300" alt="Road Card for Kurla Andheri Road"> | <img src="docs/my-ward.png" width="300" alt="My Ward screen for L ward"> |

## How to open it

- **Quickest:** double-click `app/index.html`. It works straight from disk; location is off there, so it shows the sample road (Kurla Andheri Road) with a note.
- **With location:** `cd app && python3 -m http.server 8000`, then open <http://localhost:8000> and use your browser's phone view (390 px).
- **On a phone:** host the `app/` folder on GitHub Pages (or any HTTPS host). Browsers allow location only over HTTPS or localhost.

No login, no backend. "Me too" taps are saved only on that device. The RTI name and address are never stored.

### Android app (APK)

`AplaBMC.apk` is the same web app bundled into a small Android wrapper (`android/`, plain Java, no libraries). It works offline except for the web fonts. To install it, send the file to the phone, open it and allow "Install unknown apps". It is debug-signed: fine for sideloading, not for the Play Store. To rebuild it after changing `app/`:

```bash
cd android && JAVA_HOME=<jdk-17> ./gradlew assembleDebug   # → app/build/outputs/apk/debug/app-debug.apk
```

Set `PUBLIC_URL` in `app/app.js` once the app is hosted, so WhatsApp shares from the APK carry a real link.

## How it's built

```
scripts/build_apla_data.py   dataset CSVs → app/apla_data.json (+ apla_data.js for file:// use)
app/index.html · styles.css  one mobile page, plain HTML + JS, no build step
app/i18n.js                  every UI label: translations = { mr, hi, en }
app/app.js                   screens: Home · Road Card · Ask BMC (RTI) · My Ward
tests/check.mjs              logic checks against the spec's test cases (Node)
tests/e2e.mjs                drives the real page in headless Chrome at 360 px
```

The app never recalculates; it only reads `apla_data.json`. To rebuild from the dataset:

```bash
python3 -I scripts/build_apla_data.py <path-to>/Claude-Impact-Labs-data-2/data app/
node tests/check.mjs && node tests/e2e.mjs
```

The builder checks itself against the spec's numbers (Kurla Andheri Road ₹30,52,667 billed vs ₹29,51,740 fair, 35 jobs, 6 broke again, 6 on time; L ward budget ₹1.19 crore, spent ₹1.30 crore).

## How each number is worked out

Every number comes from the dataset. The rules, so anyone can check them:

| Shown as | Rule |
|---|---|
| Money spent | Sum of `cost_inr` of the road's work orders |
| Should have cost | `rate_card.csv`: per-sqm methods × `area_sqm`, per-job methods at the standard rate |
| Broke again / on time | Count of `reopened_within_30d = Y` / `sla_met = Y` |
| Under guarantee | `roads.csv` `under_dlp = Y` |
| 🔴 Built weak | Resurfaced since Jan 2023, yet 6 or more pothole / cave-in / paver repairs this monsoon |
| 🔴 Billed twice | A job with no complaint behind it, same road and same method as another job within 7 days |
| 🔴 Overcharged | Billed at least 1.5× the rate card (normal jobs sit at 0.75–1.3×, so normal variation is not flagged) |
| 🟠 Paid despite guarantee | Pothole / cave-in / paver repair paid by BMC on a road under guarantee |
| 🟠 Pump with no rain | Pump job on a day when Santacruz and Colaba both had under 2.5 mm that day and the day before |
| 🟠 Dug by utility company | Engineer remark says MTNL/MGL trench, so the cost should be recovered from them |
| Contractor grade | City-wide: 50% "fix held up" + 30% "on time" + 20% "price vs rate card"; A ≥ 80, B ≥ 70, C ≥ 60, D ≥ 50 |
| Complaint trail | Complaints linked to the road's jobs; open complaints are matched to a road by the road name in the text plus their ward, else the nearest road within 300 m of the GPS point. "Days open" is counted up to 10 Oct 2025, the last date in the data |
| Me too count | Sum of `upvotes` on the road's complaints, plus your tap |

**Known limits.** The dataset has no road-owner column, so no road is marked "Not BMC". That state is built, and it switches on for any road whose `owner` in the JSON is not `"BMC"`. The ward summaries and RTI letters are filled-in templates written from each road's records (all three languages), not live Claude calls. Grades are city-wide and do not yet adjust for low-lying wards or heavy-rain weeks.

## Dataset credit

Uses **Follow the Rupee: Mumbai Monsoon Roads** by Sumeet Doshi for Claude Impact Lab Mumbai — <https://github.com/SumeetGDoshi/Claude-Impact-Labs-data-2>, licensed [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). **All data is synthetic and all contractors are fictional.** Ward codes, locality and road names are real names used only for realism; every amount, date and record is made up. Don't use it to judge any real person, contractor or department.
