"use strict";
// Apla BMC — citizen app. Reads apla_data.json (or apla_data.js) and only displays it; no recalculation.

const MYBMC_URL = "https://portal.mcgm.gov.in/";
const RTI_URL = "https://rtionline.maharashtra.gov.in/";
const DEPT_URL = "https://mmrda.maharashtra.gov.in/";
const FAR_KM = 25; // farther than this from every road = not in Mumbai
const PUBLIC_URL = ""; // e.g. https://<team>.github.io/<repo>/app/index.html — used in WhatsApp links once hosted
const APK_HOST = "appassets.androidplatform.net"; // origin the Android app serves its bundled files from
const LANGS = ["mr", "hi", "en"];
const RED_FLAGS = new Set(["built_weak", "billed_twice", "overcharged"]);

const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* private mode: memory only */ } },
};

const state = {
  data: null, lang: LANGS.includes(store.get("apla_lang")) ? store.get("apla_lang") : "mr",
  note: null, noteRoad: null, photoUrl: null, locating: false, query: "",
  tax: "", rtiName: "", rtiAddr: "", meTooMem: new Set(), navDepth: 0,
};
const roadById = new Map();
const wardByCode = new Map();

// ---------- formatting ----------
const T = () => translations[state.lang];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const trimZeros = (s) => (s.includes(".") ? s.replace(/0+$/, "").replace(/\.$/, "") : s);

function money(n, lang = state.lang) {
  const t = translations[lang];
  n = Math.round(Math.abs(n));
  if (n >= 1e7) return `₹${(n / 1e7).toFixed(2)} ${t.crore}`;
  if (n >= 1e6) return `₹${trimZeros((n / 1e5).toFixed(1))} ${t.lakh}`;
  if (n >= 1e5) return `₹${trimZeros((n / 1e5).toFixed(2))} ${t.lakh}`;
  return "₹" + n.toLocaleString("en-IN");
}
const count = (n) => Number(n).toLocaleString("en-IN");
function monthYear(iso) {
  const [y, m] = iso.split("-").map(Number);
  return `${MONTHS[state.lang][m - 1]} ${y}`;
}
function dayMonthYear(iso) {
  const [y, m, d] = iso.split("-").map(Number);
  return `${d} ${MONTHS[state.lang][m - 1]} ${y}`;
}
function today() {
  const d = new Date();
  return [d.getDate(), d.getMonth() + 1].map((x) => String(x).padStart(2, "0")).join("-") + "-" + d.getFullYear();
}
const wardName = (code) => wardByCode.get(code)?.names?.[state.lang] || wardByCode.get(code)?.name || code;

// ---------- data ----------
function indexData(d) {
  state.data = d;
  roadById.clear();
  wardByCode.clear();
  d.roads.forEach((r) => roadById.set(r.road_id, r));
  d.wards.forEach((w) => wardByCode.set(w.code, w));
}

function km(a, b) {
  const rad = Math.PI / 180;
  const dLat = (b[0] - a[0]) * rad, dLon = (b[1] - a[1]) * rad;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a[0] * rad) * Math.cos(b[0] * rad) * Math.sin(dLon / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.sqrt(h));
}

function nearestRoad(lat, lon) {
  let best = null, bestKm = Infinity;
  for (const r of state.data.roads) {
    const mid = [(r.start[0] + r.end[0]) / 2, (r.start[1] + r.end[1]) / 2];
    const d = km([lat, lon], mid);
    if (d < bestKm) { best = r; bestKm = d; }
  }
  return { road: best, km: bestKm };
}

const norm = (s) => String(s ?? "").normalize("NFC").toLowerCase().replace(/[^\p{L}\p{N}\p{M}]/gu, "");
const bySpent = (a, b) => b.spent_inr - a.spent_inr;

function searchRoads(q) {
  const n = norm(q);
  if (n.length < 2) return null;
  const d = state.data, groups = [], shown = new Set();
  const named = d.roads.filter((r) => norm(r.name).includes(n)).sort(bySpent).slice(0, 20);
  if (named.length) groups.push({ title: T().roadsNamed, roads: named });
  named.forEach((r) => shown.add(r.road_id));

  const wardHits = new Map(); // ward code -> matched locality (or "")
  for (const w of d.wards) {
    const names = [w.name, w.areas, ...Object.values(w.names || {})];
    if (norm(w.code) === n || names.some((s) => norm(s).includes(n))) wardHits.set(w.code, "");
  }
  for (const l of d.localities || []) {
    if (!wardHits.has(l.ward) && [l.name, ...l.aliases].some((s) => norm(s).includes(n))) wardHits.set(l.ward, l.name);
  }
  for (const [code, loc] of wardHits) {
    const roads = d.roads.filter((r) => r.ward === code && !shown.has(r.road_id)).sort(bySpent).slice(0, 12);
    if (!roads.length) continue;
    roads.forEach((r) => shown.add(r.road_id));
    groups.push({ title: T().roadsIn(`${code} · ${wardName(code)}${loc ? ` (${loc})` : ""}`), roads });
  }
  return groups;
}

// ---------- navigation ----------
function route() {
  const [page = "", ...rest] = location.hash.replace(/^#\/?/, "").split("/");
  return { page, id: decodeURIComponent(rest.join("/")) };
}
function go(hash, replace = false) {
  if (replace) { history.replaceState(null, "", hash); render(); window.scrollTo(0, 0); return; }
  if (location.hash === hash) { render(); return; }
  state.navDepth += 1;
  location.hash = hash;
}
function back() {
  if (state.navDepth > 0) { state.navDepth -= 1; history.back(); return; }
  const { page, id } = route();
  location.hash = page === "rti" ? `#/road/${encodeURIComponent(id)}` : "#/";
}
function shareLink(hash) {
  if (PUBLIC_URL) return PUBLIC_URL + hash;
  if (location.hostname === APK_HOST) return "आपला BMC app"; // in-app URL means nothing to the receiver
  return location.href.split("#")[0] + hash;
}
const waHref = (text) => "https://wa.me/?text=" + encodeURIComponent(text);
const myWard = () => (wardByCode.has(store.get("apla_ward")) ? store.get("apla_ward") : "L");

// ---------- location / photo ----------
function openRoad(id, note) {
  state.note = note;
  state.noteRoad = id;
  go(`#/road/${id}`);
}
// Location allowed only after we already fell back to the sample road: show the real road if the sample is still on screen.
function swapIfOnSample(pos) {
  const demo = state.data.meta?.demo_road || "RD0220";
  const { road, km: dist } = nearestRoad(pos.coords.latitude, pos.coords.longitude);
  const { page, id } = route();
  if (dist > FAR_KM || page !== "road" || id !== demo || state.note !== "locOff") return;
  store.set("apla_ward", road.ward);
  state.note = null;
  state.noteRoad = road.road_id;
  go(`#/road/${road.road_id}`, true);
}
// Called by the Android app when the user grants location; Android WebView times the first request out while its prompt is open.
window.aplaRetryLocation = () => {
  if (navigator.geolocation && state.note === "locOff") {
    navigator.geolocation.getCurrentPosition(swapIfOnSample, () => {}, { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 });
  }
};

function locate() {
  if (state.locating) return;
  let settled = false;
  const finish = (roadId, note) => {
    if (settled) return;
    settled = true;
    clearTimeout(watchdog);
    state.locating = false;
    openRoad(roadId, note);
  };
  const demo = state.data.meta?.demo_road || "RD0220";
  // geolocation's own timeout only starts after the permission prompt is answered; an ignored prompt never calls back
  const watchdog = setTimeout(() => finish(demo, "locOff"), 12000);
  if (!navigator.geolocation) return finish(demo, "locOff");
  state.locating = true;
  render();
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      if (settled) return swapIfOnSample(pos); // browser answered after the watchdog fired
      const { road, km: dist } = nearestRoad(pos.coords.latitude, pos.coords.longitude);
      if (dist > FAR_KM) return finish(demo, "locFar");
      store.set("apla_ward", road.ward);
      finish(road.road_id, null);
    },
    () => finish(demo, "locOff"),
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 },
  );
}

// ---------- shared pieces ----------
function langButtons(big = false) {
  return `<div class="langs${big ? " big" : ""}" role="group" aria-label="Language">` +
    LANGS.map((l) => `<button type="button" data-lang="${l}" aria-pressed="${l === state.lang}">${translations[l].langName}</button>`).join("") +
    `</div>`;
}
const topBar = () => `<div class="top"><button type="button" class="back" data-action="back">${esc(T().back)}</button>${langButtons()}</div>`;
const asOf = () => `<p class="small">${esc(T().asOf(dayMonthYear(state.data.meta?.as_of || "2025-10-10")))}</p>`;

function roadItem(r) {
  const t = T(), nf = (r.flags || []).length;
  const part = r.segments_in_ward > 1 ? ` · ${t.part(r.segment)}` : "";
  return `<button type="button" class="road-item" data-go="#/road/${esc(r.road_id)}">` +
    `<b>${esc(r.name)}</b><span class="meta">${esc(r.ward)} · ${esc(wardName(r.ward))}${esc(part)}</span>` +
    `<span class="amt num">${r.jobs ? money(r.spent_inr) : "—"}${nf ? `<small>🔴 ${nf}</small>` : ""}</span></button>`;
}

function costBars(fair, spent, guaranteeLine) {
  const t = T(), max = Math.max(fair, spent) || 1, diff = spent - fair;
  const pct = (v) => Math.max(2, Math.round((v / max) * 100));
  return `<h2>${esc(t.costTitle)}</h2>
    <div class="bar-row"><div class="lbl"><span>${esc(t.shouldCost)} <small>(${esc(t.shouldCostNote)})</small></span><span class="val num">${money(fair)}</span></div>
      <div class="bar"><span class="fair" style="width:${pct(fair)}%"></span></div></div>
    <div class="bar-row"><div class="lbl"><span>${esc(t.billed)}</span><span class="val num">${money(spent)}</span></div>
      <div class="bar"><span class="billed${diff <= 0 ? " ok" : ""}" style="width:${pct(spent)}%"></span></div></div>
    <p class="diff ${diff > 0 ? "up" : "down"}">${esc(diff > 0 ? t.extra : t.less)}: <span class="num">${money(diff)}</span></p>
    ${guaranteeLine ? `<p class="good-line">${esc(t.guaranteeZero)}</p>` : ""}`;
}

// ---------- screens ----------
function homeScreen() {
  const t = T(), w = wardByCode.get(myWard());
  return `<header class="hero"><h1 class="brand">आपला BMC</h1><p class="tagline">${esc(t.tagline)}</p></header>
    ${langButtons(true)}
    <div class="stack">
      <button type="button" class="btn teal xl" data-action="locate"${state.locating ? " disabled" : ""}>${esc(state.locating ? t.locating : t.checkNear)}</button>
      <button type="button" class="btn outline" data-action="photo">${esc(t.photoBtn)}</button>
      <input class="search" id="q" type="search" autocomplete="off" placeholder="${esc(t.searchPh)}" aria-label="${esc(t.searchPh)}" value="${esc(state.query)}">
      <div class="results" id="results">${resultsHtml()}</div>
    </div>
    <button type="button" class="btn outline ward-link" data-go="#/ward/${encodeURIComponent(w.code)}">${esc(t.myWard)}: ${esc(w.code)} (${esc(wardName(w.code))}) →</button>
    <p class="footer">${esc(t.footer)}</p>`;
}

function resultsHtml() {
  const groups = searchRoads(state.query);
  if (!groups) return "";
  if (!groups.length) return `<p class="small">${esc(T().noResults)}</p>`;
  return groups.map((g) => `<h3>${esc(g.title)}</h3>` + g.roads.map(roadItem).join("")).join("");
}

function roadScreen(r) {
  const t = T();
  const note = state.note && state.noteRoad === r.road_id ? `<p class="note">📍 ${esc(t[state.note])}</p>` : "";
  const part = r.segments_in_ward > 1 ? ` · ${t.part(r.segment)}` : "";
  const head = `<section class="road-head"><h1>${esc(r.name)}</h1>
    <p class="sub">${esc(r.ward)} · ${esc(wardName(r.ward))}${esc(part)}</p>
    ${r.bus_route ? `<span class="pill">🚌 ${esc(t.busRoute)}</span>` : ""}</section>`;
  const photo = state.photoUrl ? `<img class="photo" src="${esc(state.photoUrl)}" alt=""><p class="photo-cap">${esc(t.yourPhoto)}</p>` : "";

  let body;
  if (r.owner && r.owner !== "BMC") body = notBmcBox(r);
  else if (!r.jobs) body = noRepairBox(r);
  else body = moneyBlock(r) + statsBlock(r) + `<section class="card">${costBars(r.fair_cost_inr, r.spent_inr, r.under_guarantee)}</section>` +
    guaranteeBlock(r) + flagsBlock(r) + contractorsBlock(r) + trailBlock(r);
  const tax = r.owner && r.owner !== "BMC" ? "" : taxBlock();
  const wardBtn = `<button type="button" class="btn outline" data-go="#/ward/${encodeURIComponent(r.ward)}">${esc(t.wardLink(r.ward))}</button>`;
  return topBar() + note + head + photo + body + tax + wardBtn + asOf() + actionsBar(r);
}

const moneyBlock = (r) => `<section class="card money"><p class="label">${esc(T().moneyLabel)}</p><p class="big">${money(r.spent_inr)}</p></section>`;

function statsBlock(r) {
  const t = T(), [pre, big, post] = t.outOf(r.on_time, r.jobs);
  const late = r.on_time * 2 < r.jobs;
  return `<div class="stats">
    <div class="stat"><div class="k">${esc(t.repairs)}</div><div class="big">${r.jobs}</div></div>
    <div class="stat${r.broke_again ? " red" : ""}"><div class="k">${esc(t.brokeAgain)}</div><div class="big">${r.broke_again}</div></div>
    <div class="stat${late ? " amber" : ""}"><div class="k">${esc(t.onTime)}</div>${pre ? `<div class="of">${esc(pre)}</div>` : ""}<div class="big">${big}</div>${post ? `<div class="of">${esc(post)}</div>` : ""}</div>
  </div>`;
}

function guaranteeBlock(r) {
  if (!r.under_guarantee) return "";
  const t = T();
  return `<section class="card guarantee"><h2>✅ ${esc(t.underGuarantee)}</h2><p>${esc(t.guaranteeBody(monthYear(r.last_resurfaced)))}</p></section>`;
}

function flagsBlock(r) {
  const t = T(), flags = r.flags || [];
  if (!flags.length) return `<section class="card"><h2>${esc(t.flagsTitle)}</h2><p class="all-clear">✅ ${esc(t.noFlags)}</p></section>`;
  const items = flags.map((f) => {
    const red = RED_FLAGS.has(f.type);
    return `<details class="flag ${red ? "red" : "amber"}"><summary>${red ? "🔴" : "🟠"} ${esc(t.flagNames[f.type] || f.type)}` +
      `${f.count ? `<span class="count">${f.count}</span>` : ""}</summary><p>${esc(f.text?.[state.lang] || f.text?.en || "")}</p></details>`;
  }).join("");
  return `<section class="card"><h2>${esc(t.flagsTitle)}</h2><p class="hint">${esc(t.tapToSee)}</p>${items}</section>`;
}

function contractorsBlock(r) {
  const t = T(), list = r.contractors || [];
  if (!list.length) return "";
  const row = (c) => `<div class="contractor"><span class="grade ${esc(c.grade)}">${esc(c.grade)}</span><span class="name">${esc(c.name)}</span><span class="jobs">${esc(t.jobsN(c.jobs))}</span></div>`;
  const rest = list.slice(3);
  return `<section class="card"><h2>${esc(t.contractorsTitle)}</h2>${list.slice(0, 3).map(row).join("")}` +
    (rest.length ? `<details class="more"><summary>${esc(t.moreN(rest.length))}</summary>${rest.map(row).join("")}</details>` : "") +
    `<p class="hint" style="margin:8px 0 0">${esc(t.gradeHelp)}</p></section>`;
}

function trailBlock(r) {
  const t = T(), trail = r.trail || [];
  if (!trail.length) return `<section class="card"><h2>${esc(t.trailTitle)}</h2><p>${esc(t.noTrail)}</p></section>`;
  const rows = trail.map((x) => {
    const job = x.job ? `<span class="chip chip-id">${esc(t.job)} ${esc(x.job)}</span>` : `<span class="chip none">${esc(t.noJob)}</span>`;
    const status = x.status === "Done" ? `<span class="chip done">✓ ${esc(t.done)}</span>` : `<span class="chip open">${esc(t.stillOpen(x.days_open))}</span>`;
    return `<div class="trail"><span class="chip chip-id">${esc(t.complaint)} ${esc(x.complaint)}</span><span class="arrow">→</span>${job}<span class="arrow">→</span>${status}</div>`;
  }).join("");
  return `<section class="card"><h2>${esc(t.trailTitle)}</h2>${rows}</section>`;
}

function taxLine() {
  const n = parseInt(state.tax.replace(/\D/g, ""), 10);
  return n > 0 ? esc(T().taxLine(money(n))) : "";
}
const taxBlock = () => `<section class="card tax"><label for="tax">${esc(T().taxLabel)}</label>
  <input id="tax" type="text" inputmode="numeric" autocomplete="off" placeholder="₹" value="${esc(state.tax)}"><p class="line" id="taxline">${taxLine()}</p></section>`;

function notBmcBox(r) {
  const t = T();
  return `<div class="state-box amber">⚠️ ${esc(t.notBmc)}${r.not_bmc_complaints ? `<p class="sub">${esc(t.notBmcCount(r.not_bmc_complaints))}</p>` : ""}</div>`;
}
function noRepairBox(r) {
  const t = T();
  if (!r.open_complaints) return `<div class="state-box amber">${esc(t.noRepairAtAll)}</div>`;
  return `<div class="state-box red">⏳ ${esc(t.noRepairYet(r.max_days_open))}</div>` + trailBlock(r);
}

function roadWaText(r) {
  const t = T();
  const p = { road: r.name, ward: wardName(r.ward), spent: money(r.spent_inr), jobs: r.jobs, broke: r.broke_again,
    guarantee: r.under_guarantee, days: r.max_days_open, link: shareLink(`#/road/${r.road_id}`) };
  if (r.owner && r.owner !== "BMC") return t.waNotBmc(p);
  if (!r.jobs && r.open_complaints) return t.waNoRepair(p);
  return t.waRoad(p);
}
const hasMeToo = (id) => store.get(`apla_metoo_${id}`) === "1" || state.meTooMem.has(id);

function actionsBar(r) {
  const t = T();
  const wa = `<a class="btn green" href="${esc(waHref(roadWaText(r)))}" target="_blank" rel="noopener">${esc(t.whatsapp)}</a>`;
  let buttons;
  if (r.owner && r.owner !== "BMC") {
    buttons = [wa, `<a class="btn outline" href="${DEPT_URL}" target="_blank" rel="noopener">${esc(t.deptLink)}</a>`];
  } else {
    const mine = hasMeToo(r.road_id);
    const me = `<button type="button" class="btn amber${mine ? " done" : ""}" data-action="metoo" data-id="${esc(r.road_id)}" aria-pressed="${mine}">` +
      `<span>${esc(mine ? t.meTooDone : t.meToo)} · <span class="num">${count((r.me_too || 0) + (mine ? 1 : 0))}</span></span></button>`;
    const rti = r.rti_text ? `<button type="button" class="btn teal" data-go="#/rti/${esc(r.road_id)}">${esc(t.askBmc)}</button>` : "";
    const my = `<a class="btn outline" href="${MYBMC_URL}" target="_blank" rel="noopener">${esc(t.myBmc)}</a>`;
    buttons = [me, wa, rti, my].filter(Boolean);
  }
  return `<nav class="actions" aria-label="Actions"><div class="grid">${buttons.join("")}</div></nav>`;
}

function rtiFilled(r) {
  const blank = "__________";
  return (r.rti_text?.[state.lang] || r.rti_text?.en || "")
    .replaceAll("{NAME}", state.rtiName.trim() || blank)
    .replaceAll("{ADDRESS}", state.rtiAddr.trim().replace(/\s*\n\s*/g, ", ") || blank)
    .replaceAll("{DATE}", today());
}

function rtiScreen(r) {
  const t = T();
  if (!r.rti_text) return topBar() + `<p class="state-box amber">${esc(t.noRti)}</p>`;
  const text = rtiFilled(r);
  return topBar() + `<section class="road-head"><h1>${esc(t.rtiTitle)}</h1>
      <p class="sub">${esc(r.name)} · ${esc(r.ward)} · ${esc(wardName(r.ward))}</p></section>
    <p>${esc(t.rtiIntro)}</p>
    <div class="form">
      <label for="rname">${esc(t.yourName)}</label><input id="rname" autocomplete="off" value="${esc(state.rtiName)}">
      <label for="raddr">${esc(t.yourAddress)}</label><textarea id="raddr" autocomplete="off">${esc(state.rtiAddr)}</textarea>
    </div>
    <p class="hint" style="margin-top:6px">🔒 ${esc(t.notSaved)}</p>
    <div class="rti-text" id="rtitext">${esc(text)}</div>
    <div class="stack">
      <button type="button" class="btn teal" data-action="copy" data-id="${esc(r.road_id)}">${esc(t.copy)}</button>
      <a class="btn green" id="rtiwa" href="${esc(waHref(text))}" target="_blank" rel="noopener">${esc(t.whatsapp)}</a>
      <a class="btn outline" href="${RTI_URL}" target="_blank" rel="noopener">${esc(t.rtiHow)}</a>
    </div>
    <p class="small" style="margin-top:12px">${esc(t.rtiFee)}</p>`;
}

function wardScreen(w) {
  const t = T(), lang = state.lang, diff = w.spent_inr - w.budget_inr;
  const options = state.data.wards.map((x) => `<option value="${esc(x.code)}"${x.code === w.code ? " selected" : ""}>${esc(x.code)} · ${esc(wardName(x.code))}</option>`).join("");
  const chips = Object.entries(w.flag_counts || {}).filter(([, n]) => n > 0)
    .map(([k, n]) => `<span class="chip ${RED_FLAGS.has(k) ? "red" : "amber"}">${esc(t.flagNames[k] || k)} <span class="num">${n}</span></span>`).join("");
  const top = (w.top_roads || []).map((id) => roadById.get(id)).filter(Boolean).map(roadItem).join("");
  const grades = (w.contractors || []).map((c) => `<span class="chip"><span class="grade ${esc(c.grade)}">${esc(c.grade)}</span>${esc(c.name)}</span>`).join("");
  const summary = w.summary?.[lang] || w.summary?.en || "";
  const waText = t.waWard(w.code, summary, shareLink(`#/ward/${encodeURIComponent(w.code)}`));
  return topBar() + `<section class="road-head"><h1>${esc(t.wardTitle)} · ${esc(w.code)} · ${esc(wardName(w.code))}</h1>
      <p class="sub"><label>${esc(t.changeWard)}: <select class="ward-pick" id="wardpick">${options}</select></label></p></section>
    <section class="card"><p class="sentence">${esc(t.wardSentence(w.code, money(w.budget_inr), money(w.spent_inr), money(diff), diff >= 0))}</p></section>
    <section class="card">${costBars(w.fair_cost_inr, w.spent_inr, false)}</section>
    <section class="card lost"><h2>${esc(t.lostFailed)}</h2><p class="big num">${money(w.lost_failed_inr)}</p><p class="hint" style="margin:0">${esc(t.lostFailedNote)}</p></section>
    <section class="card"><h2>${esc(t.wardFlags)}</h2><div class="counts">${chips || `<p class="all-clear">✅ ${esc(t.noFlags)}</p>`}</div></section>
    <section class="card"><h2>${esc(t.bmcAnswers)}</h2><div class="answers">
      <div>${esc(t.answered)} ✅<span class="big num">${w.bmc_answered ?? 0}</span></div>
      <div>${esc(t.pending)} ❌<span class="big num">${w.bmc_pending ?? 0}</span></div></div></section>
    <section class="card"><h2>${esc(t.topRoads)}</h2><div class="results">${top}</div></section>
    <section class="card"><h2>${esc(t.wardContractors)}</h2><div class="grades">${grades}</div><p class="hint" style="margin:8px 0 0">${esc(t.gradeHelp)}</p></section>
    <section class="card"><h2>${esc(t.summaryTitle)}</h2><p class="summary-text">${esc(summary)}</p></section>
    <a class="btn green" href="${esc(waHref(waText))}" target="_blank" rel="noopener">${esc(t.shareWard)}</a>
    ${asOf()}`;
}

// ---------- render + events ----------
function render() {
  const app = document.getElementById("app");
  const { page, id } = route();
  document.documentElement.lang = state.lang;
  if (page !== "road") state.note = null;
  let html;
  if (page === "road" && roadById.has(id)) html = roadScreen(roadById.get(id));
  else if (page === "rti" && roadById.has(id)) html = rtiScreen(roadById.get(id));
  else if (page === "ward" && wardByCode.has(id)) html = wardScreen(wardByCode.get(id));
  else html = homeScreen();
  app.innerHTML = html;
  app.classList.toggle("with-actions", page === "road" && roadById.has(id));
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  }
}

function wire() {
  const app = document.getElementById("app");
  const photo = document.getElementById("photo");
  app.addEventListener("click", async (e) => {
    const el = e.target.closest("[data-lang],[data-go],[data-action]");
    if (!el) return;
    if (el.dataset.lang) {
      state.lang = el.dataset.lang;
      store.set("apla_lang", state.lang);
      render();
      return;
    }
    if (el.dataset.go) return go(el.dataset.go);
    const action = el.dataset.action, id = el.dataset.id;
    if (action === "back") back();
    else if (action === "locate") locate();
    else if (action === "photo") photo.click();
    else if (action === "metoo" && !hasMeToo(id)) {
      state.meTooMem.add(id);
      store.set(`apla_metoo_${id}`, "1");
      render();
    } else if (action === "copy") {
      if (await copyText(rtiFilled(roadById.get(id)))) {
        el.textContent = T().copied;
        setTimeout(() => { el.textContent = T().copy; }, 2000);
      } else { // clipboard blocked: select the text so a long-press copy works
        const range = document.createRange();
        range.selectNodeContents(document.getElementById("rtitext"));
        getSelection().removeAllRanges();
        getSelection().addRange(range);
      }
    }
  });
  app.addEventListener("input", (e) => {
    const el = e.target;
    if (el.id === "q") {
      state.query = el.value;
      document.getElementById("results").innerHTML = resultsHtml();
    } else if (el.id === "tax") {
      state.tax = el.value;
      document.getElementById("taxline").innerHTML = taxLine();
    } else if (el.id === "rname" || el.id === "raddr") {
      state[el.id === "rname" ? "rtiName" : "rtiAddr"] = el.value; // memory only, never stored
      const r = roadById.get(route().id), text = rtiFilled(r);
      document.getElementById("rtitext").textContent = text;
      document.getElementById("rtiwa").href = waHref(text);
    }
  });
  app.addEventListener("change", (e) => {
    if (e.target.id !== "wardpick") return;
    store.set("apla_ward", e.target.value);
    go(`#/ward/${encodeURIComponent(e.target.value)}`, true);
  });
  photo.addEventListener("change", () => {
    const file = photo.files && photo.files[0];
    if (!file) return;
    if (state.photoUrl) URL.revokeObjectURL(state.photoUrl);
    state.photoUrl = URL.createObjectURL(file); // proof only: never uploaded or analysed
    photo.value = "";
    locate();
  });
  window.addEventListener("hashchange", () => { render(); window.scrollTo(0, 0); });
}

async function boot() {
  try {
    const d = window.APLA_DATA || (await (await fetch("apla_data.json")).json());
    indexData(d);
  } catch {
    document.getElementById("app").innerHTML = `<p class="loading">apla_data.json not found</p>`;
    return;
  }
  wire();
  render();
}

if (typeof document !== "undefined" && document.getElementById("app")) boot();
